package com.juaracoding.bdd.utils;

public class Constans {
	
	public static final String CHROME = "Chrome";
	public static final String FIREFOX = "Firefox";
	public static final String URL = "https://www.phptravels.net/login";


}
