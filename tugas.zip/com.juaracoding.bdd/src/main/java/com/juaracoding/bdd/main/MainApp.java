package com.juaracoding.bdd.main;

import org.openqa.selenium.WebDriver;

import com.juaracoding.bdd.driver.DriverSingleton;

public class MainApp {
	
	public static void main(String[] args) {
		
		WebDriver driver = DriverSingleton.getInstance().getDriver();
		driver.get("https://demoqa.com/webtables");
		
		tunggu();
		driver.quit();
	}
	public static void tunggu() {
		try {
			Thread.sleep(3000);
		}catch (InterruptedException e) {
			e.printStackTrace();	
		}
	}

}
