package com.juaracoding.bdd;

import net.bytebuddy.agent.builder.AgentBuilder.RedefinitionStrategy.DiscoveryStrategy;

public class DriverStrategyImplementor {
	
	public static DiscoveryStrategy chooseStrategy(String strategy) {
		
		switch(strategy) {
		case "chrome" :
		return (DiscoveryStrategy) new Chrome();
		
		case "firefox":
			return Firefox();
			
			default:
				return null;
		}
	}

	private static DiscoveryStrategy Firefox() {
		// TODO Auto-generated method stub
		return null;
	}

}
