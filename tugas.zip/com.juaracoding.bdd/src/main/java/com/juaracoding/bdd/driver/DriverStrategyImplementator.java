package com.juaracoding.bdd.driver;

import org.openqa.selenium.firefox.FirefoxDriver;

import com.juaracoding.bdd.Chrome;
import com.juaracoding.bdd.utils.Constans;

public class DriverStrategyImplementator {
	
	public static DriverStrategy chooseStrategy(String strategy) {
		
		switch(strategy) {
		case Constans.CHROME:
			return new Chrome();
			
		case Constans.FIREFOX:
			return new FirefoxDriver();
			
			default:
				return null;
				
		}
		
	}

}
