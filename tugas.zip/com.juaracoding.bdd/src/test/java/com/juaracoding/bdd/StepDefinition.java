package com.juaracoding.bdd;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.juaracoding.bdd.config.AutomationFrameworkConfig;
import com.juaracoding.bdd.driver.DriverSingleton;
import com.juaracoding.bdd.pages.LoginPage;
import com.juaracoding.bdd.utils.ConfigurationProperties;
import com.juaracoding.bdd.utils.Constans;

import io.cucumber.java.AfterAll;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

@CucumberContexConfiguration
@ContextConfiguration(classes = AutomationFrameworkConfig.class)
public class StepDefinition {
	
	private static WebDriver driver;
	private LoginPage loginPage;
	
	@Autowired
	ConfigurationProperties configurationProperties;
	
	@Before
	public void setUp() {
		DriverSingleton.getInstance(configurationProperties.getBrowser());
		loginPage = new LoginPage();
	}
	@AfterAll
	public static void quitDriver() {
		driver.quit();
	}
	
	@Given("Customer mengakses url")
	public void customer_mengakses_url() {
		driver = DriverSingleton.getDriver();
		driver.get(Constans.URL);
	}
	@When("Customer login dengan username dan password")
	public void Customer_login_dengan_username_password() {
		loginPage.LoginForm(configurationProperties.getEmail(),configurationProperties.getPassword() );
	}
	@Then("Customer berhasil login")
	public void Customer_berhasil_login() {
		assertEquals(configurationProperties.getTxtWelcome(), loginPage.getTxtWelcome());
	}
}
